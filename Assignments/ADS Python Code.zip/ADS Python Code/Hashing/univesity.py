import numpy as np

class university:
	progSize = 11
	class _Student:
		def __init__(self, inst, name, proid, regNo, grade, gender):
			self.inst = inst
			self.stdName = name
			self.program = proid
			self.regNum = regNo
			self.grade = grade
			self.gender = gender
	def __init__(self):
		self.p = 13
		self.a = np.random.randint(1, 13)
		self.b = np.random.randint(0, 13)
		self.hash_table0 = []
		self.hash_table1 = []
		self.hash_table2 = []
		self._initialize()

	def _initialize(self):
		self.hash_table0 = [None]*university.progSize

	def _hash_value(self, progID):
		hashvalue = 0
		for ch in str(progID):
			hashvalue = hashvalue << 5
			hashvalue = hashvalue + ord(ch)

		return hashvalue

	def _compression(self, hashvalue):
		return ( ((self.a * hashvalue + self.b) % self.p) % OpenHashing.tableSize)

	def _hashing(self, element):
		hash_num = self._hash_value(element)
		hash_index = self._compression(hash_num)
		return hash_index

	def is_member(self, inst, progID, regNo):
		bucket = self._hashing(element)
		current = self.hashtable[bucket]
		while not current is None:
			if current.ssn == element:
				return True
			else:
				current = current.next

		return False


