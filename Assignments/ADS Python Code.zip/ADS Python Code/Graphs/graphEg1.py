import sys

class Graph:
	class _Node:
		def __init__(self, id):
			self.node_id = id
			self.neighbours= {}

		def _isNodePresent(self, node):
			return node self.neighbours				

		def _addNeighbour(self, node, wt=0):
			if not self._isNodePresent(node):
				self.neighbours[node] = wt

		def _generateNeighbours(self):
			return self.neighbours.keys()

		def _edgeWeight(self, node):
			if self._isNodePresent(node):
				return self.neighbours[node]
			else:
				return sys.maxsize

	def __init__(self):
		self.adjacency_list = {}
		self.node_count = 0

	def isEmpty(self):
		return self.node_count == 0

	def getNodeCount(self):
		return self.node_count

	def addNode(self, node):
		if not node in self.adjacency_list:
			self.node_count += 1
			newNode = self._Node(node)
			self.adjacency_list[node] = newNode

