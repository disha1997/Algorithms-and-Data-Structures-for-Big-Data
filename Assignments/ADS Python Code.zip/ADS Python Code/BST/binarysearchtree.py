class BST:
	class _Node:
		def __init__(self, val):
			self.data = val
			self.left = None
			self.right = None
	def __init__(self):
		self.root = None
		self.mass = 0

	def bstAddNode(self, ele):
		node = parent = self.root
		while node != None and node.data != ele:
			parent = node
			if ele < node.data:
				node = node.left
			else:
				node = node.right

		if node == None:
			newNode = self._Node(ele)
			if parent == None:
				self.root = newNode
			elif ele < parent.data:
				parent.left = newNode
			elif ele > parent.data:
				parent.right = newNode
			self.mass += 1

	def bstSearchNode(self, key):
		node = self.root
		while node != None:
			if key < node.data:
				node = node.left
			elif key > node.data:
				node = node.right
			else:
				break
		return node != None


	def bstIsEmpty(self):
		return self.mass == 0

	def bstNodeCount(self):
		return self.mass

	def bstInorder(self):
		if not self.bstIsEmpty():
			self._inorder(self.root)

	def _inorder(self, node):
		if node != None:
			self._inorder(node.left)
			print (node.data)
			self._inorder(node.right)

	def bstPreorder(self):
		if not self.bstIsEmpty():
			self._preorder(self.root)

	def _preorder(self, node):
		if node != None:			
			print (node.data)
			self._preorder(node.left)
			self._preorder(node.right)


	def bstPostorder(self):
		if not self.bstIsEmpty():
			self._postorder(self.root)

	def _postorder(self, node):
		if node != None:						
			self._postorder(node.left)
			self._postorder(node.right)
			print (node.data)

	def levelOrder(self):
		if not self.bstIsEmpty():
			q1 = flexiQueue()
			node = self.root
			q1.enqueue(node)
			#print (node.data)
			while node:
				node = q1.dequeue()
				print (node.data)
				if node.left:
					q1.enqueue(node.left)
				if node.right:
					q1.enqueue(node.right)

	def bstDeleteNode(self, ele):
		if not self.bstIsEmpty():
			self.root = self._nodeDelete(self.root, ele)

	def _nodeDelete(self, node, key):
		if node == None:
			return None
		elif key < node.data:
			node.left = self._nodeDelete(node.left, key)
		elif key > node.data:
			node.right = self._nodeDelete(node.right, key)
		elif node.left and node.right:
			tempNode = self._findMin(node.right)
			node.data = tempNode.data
			node.right = self._nodeDelete(node.right, node.data)
		else:
			if node.right == None:
				node = node.left
			elif node.left == None:
				node = node.right
			self.mass -= 1
		return node
		
	def _findMin(self, node):
		if not node.left:
			return node
		else:
			return _findMin(node.left)

	def getLeafNodeCount(self):
		return self.leafCount(self.root)

	def leafCount(self, treeNode):
		if treeNode:
			if self.isLeafNode(treeNode):
				return 1
			else:
				return (self.leafCount(treeNode.left) + self.leafCount(treeNode.right))
		else:
			return 0

	def isLeafNode(self, treeNode):
		if treeNode.left== None and treeNode.right == None:
			return True
		else:
			return False

def test_bst():
	bst1 = BST()
	assert(bst1.bstIsEmpty())
	bst1.bstAddNode(50)
	bst1.bstAddNode(75)
	bst1.bstAddNode(30)
	bst1.bstAddNode(95)	
	bst1.bstAddNode(90)
	assert(bst1.bstSearchNode(30))
	assert(bst1.bstNodeCount() == 5)
	#bst1.bstInorder()
	#bst1.bstPreorder()
	#bst1.bstPostorder()
	bst1.bstDeleteNode(75)
	#assert(bst1.bstNodeCount() == 4)
	bst1.bstInorder()
	bst1.bstAddNode(45)
	bst1.bstAddNode(25)
	print (bst1.getLeafNodeCount())


test_bst()