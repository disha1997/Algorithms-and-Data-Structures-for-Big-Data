class maxHeap:
	def __init__ (self, lst=[]):
		self.data = lst
		self._buildHeap()

	def getLength(self):
		return len(self.data)

	def isEmpty(self):
		return len(self.data) == 0

	def _parent(self, j):
		return (j-1)//2

	def _leftChild(self, j):
		return (2*j +1)

	def _rightChild(self, j):
		return (2*j + 2)

	def _swap(self, i, j):
		self.data[i], self.data[j] = self.data[j], self.data[i]

	def upHeap(self, j):
		parent = self._parent(j)
		if j > 0 and self.data[j] > self.data[parent]:
			self._swap(j, parent)
			self.upHeap(parent)
	def _downHeap(self, parent, size):
		if self._leftChild(parent) < size:
			left = self._leftChild(parent)
			bigChild = left

			if self._rightChild(parent) < size:
				right = self._rightChild(parent)
				if self.data[right] > self.data[left]:
					bigChild = right
			if self.data[bigChild] > self.data[parent]:
				self._swap(bigChild, parent)
				self._downHeap(bigChild, size)

	def _buildHeap(self):
		length = len(self.data)
		start = (length - 2)//2
		for idx in range(start, -1, -1):
			self._downHeap(idx, length)

	def addElement(self, key):
		self.data.append(key)
		self.upHeap(len(self.data)-1)

	def testMaxHeap(self):
		if not self.isEmpty():
			for idx in range(len(self.data)-1, 0, -1):
				assert(self.data[idx] <= self.data[self._parent(idx)])

	def heap_sort(self):
		if not self.isEmpty():
			for idx in range(self.getLength()-1, 0, -1):
				self._swap(0, idx)
				self._downHeap(0, idx)





