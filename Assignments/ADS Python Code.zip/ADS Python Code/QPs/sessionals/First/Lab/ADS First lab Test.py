from limitedStack import *
from flexiQueue import *

class scanStack:
	def __init__(self):
		self.s1 = limitedStack()
		self.q1 = flexiQueue()

	def addToStack(self, ele):
		self.s1.push(ele)

	def scanElement(self, key):
		count = 0
		while not self.s1.peek() == key or self.s1.isEmpty()!=True:
			self.q1.enqueue(self.s1.pop())
			count += 1
		if not self.s1.isEmpty():
			print(str(key) +" found.")
			self.rearrange(count)
		else:
			print(str(key) + " not found.")

	def rearrange(self, count):
		while not self.q1.isEmpty():
			self.s1.push(self.q1.dequeue())

		while count != 0:
			self.q1.enqueue(self.s1.pop())
			count -= 1

		while not self.q1.isEmpty():
			self.s1.push(self.q1.dequeue())
			