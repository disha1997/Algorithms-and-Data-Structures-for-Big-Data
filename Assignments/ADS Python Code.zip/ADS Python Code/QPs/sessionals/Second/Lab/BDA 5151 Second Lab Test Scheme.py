def findSum(l1, key):
	up = 0
	down = len(l1) - 1
	result = []
	while (up <= down):
		if l1[up]+l1[down] == key:
			result.append((l1[up], l1[down]))
			up+=1
			down -=1
		elif l1[up]+l1[down] < key:
			up += 1

		elif l1[up]+l1[down] > key:
			down -= 1
	return result


def mergeSort(mylist):
	if len(mylist) == 0 or len(mylist) == 1:
		return mylist
	else:
		mid = len(mylist)//2
		a = mergeSort(mylist[:mid])
		b = mergeSort(mylist[mid:])
		return merge(a, b)

def merge(a, b):
	temp_list = []

	while len(a) != 0 and len(b) != 0:
		if a[0] < b[0]:
			temp_list.append(a[0])
			a.pop(0)
		else:
			temp_list.append(b[0])
			b.pop(0)
	if len(a) == 0:
		temp_list = temp_list + b
	else:
		temp_list = temp_list + a

	return temp_list

def testProgram():
	l1 = mergeSort(input)
	print(findSum(l1, key))

testProgram()


